/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shalaka.medical;

/**
 *
 * @author HP
 */

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;
public class medicine extends javax.swing.JFrame {

    /**
     * Creates new form medicine
     */
    public medicine() {
        initComponents();
        selectmed();
        Getcompany();
    }
 Connection con =null;
 Statement St =null;
 ResultSet Rs =null;
 java.util.Date FDate,EDate;
 java.sql.Date MyfabDate,MyexpDate;
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        MANAGEMEDICINE = new javax.swing.JLabel();
        MEDICINEID = new javax.swing.JLabel();
        MEDNAME = new javax.swing.JLabel();
        PRICE = new javax.swing.JLabel();
        QUANTITY = new javax.swing.JLabel();
        MAFDATE = new javax.swing.JLabel();
        EXPDATE = new javax.swing.JLabel();
        COMPANY = new javax.swing.JLabel();
        MEDID = new javax.swing.JTextField();
        COMPANYCH = new javax.swing.JComboBox<String>();
        MEDPRICE = new javax.swing.JTextField();
        MDNAME = new javax.swing.JTextField();
        MEDQTY = new javax.swing.JTextField();
        ADDBT = new javax.swing.JButton();
        DELETEBT = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        MedicineTable = new javax.swing.JTable();
        MEDICINELIST = new javax.swing.JLabel();
        MEDMAF = new com.toedter.calendar.JDateChooser();
        MEDEXP = new com.toedter.calendar.JDateChooser();
        UPDATEBT = new javax.swing.JButton();
        CLEARBT = new javax.swing.JButton();
        shalaka = new javax.swing.JLabel();
        COMPANYLABLE = new javax.swing.JLabel();
        CUSTOMERLABLE = new javax.swing.JLabel();
        X = new javax.swing.JLabel();
        shalaka1 = new javax.swing.JLabel();
        shalaka2 = new javax.swing.JLabel();
        shalaka3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(153, 0, 153));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        MANAGEMEDICINE.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        MANAGEMEDICINE.setForeground(new java.awt.Color(153, 0, 153));
        MANAGEMEDICINE.setText("MANAGE MEDICINE");

        MEDICINEID.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MEDICINEID.setForeground(new java.awt.Color(153, 0, 153));
        MEDICINEID.setText("MEDICINE ID");

        MEDNAME.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MEDNAME.setForeground(new java.awt.Color(153, 0, 153));
        MEDNAME.setText("MEDNAME");

        PRICE.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        PRICE.setForeground(new java.awt.Color(153, 0, 153));
        PRICE.setText("PRICE");

        QUANTITY.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        QUANTITY.setForeground(new java.awt.Color(153, 0, 153));
        QUANTITY.setText("QUANTITY");

        MAFDATE.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MAFDATE.setForeground(new java.awt.Color(153, 0, 153));
        MAFDATE.setText("MAFDATE");

        EXPDATE.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        EXPDATE.setForeground(new java.awt.Color(153, 0, 153));
        EXPDATE.setText("EXPDATE");

        COMPANY.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        COMPANY.setForeground(new java.awt.Color(153, 0, 153));
        COMPANY.setText("COMPANY");

        MEDID.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N

        COMPANYCH.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        COMPANYCH.setForeground(new java.awt.Color(204, 0, 255));

        MEDPRICE.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        MEDPRICE.setForeground(new java.awt.Color(102, 0, 153));
        MEDPRICE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MEDPRICEActionPerformed(evt);
            }
        });

        MDNAME.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        MDNAME.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MDNAMEActionPerformed(evt);
            }
        });

        MEDQTY.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N

        ADDBT.setBackground(new java.awt.Color(153, 0, 153));
        ADDBT.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        ADDBT.setForeground(new java.awt.Color(255, 255, 255));
        ADDBT.setText("ADD");
        ADDBT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ADDBTMouseClicked(evt);
            }
        });
        ADDBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ADDBTActionPerformed(evt);
            }
        });

        DELETEBT.setBackground(new java.awt.Color(153, 0, 153));
        DELETEBT.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        DELETEBT.setForeground(new java.awt.Color(255, 255, 255));
        DELETEBT.setText("DELETE");
        DELETEBT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DELETEBTMouseClicked(evt);
            }
        });
        DELETEBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DELETEBTActionPerformed(evt);
            }
        });

        MedicineTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "MEDNAME", "PRICE", "QUANTITY", "MAFDATE", "EXPDATE", "COMPANY"
            }
        ));
        MedicineTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MedicineTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(MedicineTable);

        MEDICINELIST.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MEDICINELIST.setForeground(new java.awt.Color(153, 0, 153));
        MEDICINELIST.setText("MEDICINES LIST");

        UPDATEBT.setBackground(new java.awt.Color(153, 0, 153));
        UPDATEBT.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        UPDATEBT.setForeground(new java.awt.Color(255, 255, 255));
        UPDATEBT.setText("UPDATE");
        UPDATEBT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UPDATEBTMouseClicked(evt);
            }
        });
        UPDATEBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UPDATEBTActionPerformed(evt);
            }
        });

        CLEARBT.setBackground(new java.awt.Color(153, 0, 153));
        CLEARBT.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        CLEARBT.setForeground(new java.awt.Color(255, 255, 255));
        CLEARBT.setText("CLEAR");
        CLEARBT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CLEARBTMouseClicked(evt);
            }
        });
        CLEARBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CLEARBTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(260, 260, 260)
                        .addComponent(MANAGEMEDICINE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(MEDICINEID)
                                            .addComponent(MEDNAME)
                                            .addComponent(QUANTITY)
                                            .addComponent(PRICE))
                                        .addGap(49, 49, 49)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(MEDQTY, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(MEDPRICE, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(MDNAME, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(MEDID, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(92, 92, 92)
                                        .addComponent(ADDBT, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(CLEARBT, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 77, Short.MAX_VALUE)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(MAFDATE)
                                            .addComponent(EXPDATE)
                                            .addComponent(COMPANY)))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(38, 38, 38)
                                        .addComponent(UPDATEBT, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(45, 45, 45)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(MEDMAF, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(MEDEXP, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(COMPANYCH, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(5, 5, 5)
                                        .addComponent(DELETEBT, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 767, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(43, 43, 43))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(MEDICINELIST)
                .addGap(341, 341, 341))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(MANAGEMEDICINE)
                .addGap(63, 63, 63)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(MAFDATE)
                            .addComponent(MEDMAF, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(MEDICINEID)
                            .addComponent(MEDID, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(MDNAME, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(MEDNAME))
                            .addComponent(EXPDATE, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(PRICE, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(MEDPRICE, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(COMPANY)
                                .addComponent(COMPANYCH, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(MEDEXP, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(QUANTITY)
                    .addComponent(MEDQTY, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(63, 63, 63)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ADDBT)
                    .addComponent(UPDATEBT)
                    .addComponent(CLEARBT)
                    .addComponent(DELETEBT))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                .addComponent(MEDICINELIST)
                .addGap(40, 40, 40)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(66, 66, 66))
        );

        shalaka.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        shalaka.setForeground(new java.awt.Color(255, 255, 255));
        shalaka.setText("BILLING");
        shalaka.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shalakaMouseClicked(evt);
            }
        });

        COMPANYLABLE.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        COMPANYLABLE.setForeground(new java.awt.Color(255, 255, 255));
        COMPANYLABLE.setText("COMPANY");
        COMPANYLABLE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                COMPANYLABLEMouseClicked(evt);
            }
        });

        CUSTOMERLABLE.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        CUSTOMERLABLE.setForeground(new java.awt.Color(255, 255, 255));
        CUSTOMERLABLE.setText("CUSTOMER");
        CUSTOMERLABLE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CUSTOMERLABLEMouseClicked(evt);
            }
        });

        X.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        X.setForeground(new java.awt.Color(255, 255, 255));
        X.setText("X");
        X.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                XMouseClicked(evt);
            }
        });

        shalaka1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        shalaka1.setForeground(new java.awt.Color(255, 255, 255));
        shalaka1.setText("AGENT");
        shalaka1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shalaka1MouseClicked(evt);
            }
        });

        shalaka2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        shalaka2.setForeground(new java.awt.Color(255, 255, 255));
        shalaka2.setText("HOME");
        shalaka2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shalaka2MouseClicked(evt);
            }
        });

        shalaka3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        shalaka3.setForeground(new java.awt.Color(255, 255, 255));
        shalaka3.setText("CONTACT US");
        shalaka3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shalaka3MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(COMPANYLABLE)
                    .addComponent(CUSTOMERLABLE)
                    .addComponent(shalaka1)
                    .addComponent(shalaka2)
                    .addComponent(shalaka3)
                    .addComponent(shalaka))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(30, 30, 30))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(X)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(X)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(95, 95, 95)
                        .addComponent(shalaka2)
                        .addGap(18, 18, 18)
                        .addComponent(COMPANYLABLE)
                        .addGap(18, 18, 18)
                        .addComponent(CUSTOMERLABLE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(shalaka1)
                        .addGap(18, 18, 18)
                        .addComponent(shalaka)
                        .addGap(18, 18, 18)
                        .addComponent(shalaka3)
                        .addContainerGap(509, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(21, 21, 21))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
  public void selectmed()
  {
      try
      {
      con= DriverManager.getConnection("jdbc:derby://localhost:1527/USER1","USER1","USER1");
      St= con.createStatement();
      Rs = St.executeQuery("select * from USER1.MEDICINETB");
      MedicineTable.setModel(DbUtils.resultSetToTableModel(Rs));
      }
      catch(SQLException e)
      {
          e.printStackTrace();
      }
  }
  
  public void Getcompany()
  {
    try
     {
       con= DriverManager.getConnection("jdbc:derby://localhost:1527/USER1","USER1","USER1");  
       St= con.createStatement();
        String query ="select * from USER1.COMPANYTB";
       Rs = St.executeQuery(query);
       while (Rs.next()){
        String Mycomp = Rs.getString("COMPNAME");
        COMPANYCH.addItem(Mycomp);
        
           
       }
     }
     catch(SQLException e)
     {
         e.printStackTrace();
     }
  }
  
    
    private void ADDBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ADDBTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ADDBTActionPerformed

    private void DELETEBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DELETEBTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DELETEBTActionPerformed

    private void MEDPRICEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MEDPRICEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MEDPRICEActionPerformed

    private void MDNAMEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MDNAMEActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MDNAMEActionPerformed

    private void ADDBTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ADDBTMouseClicked
      FDate = MEDMAF.getDate();
      MyfabDate = new java.sql.Date(FDate.getTime());
      EDate = MEDEXP.getDate();
      MyexpDate =new java.sql.Date(EDate.getTime());
        try
       {
          con = DriverManager.getConnection("jdbc:derby://localhost:1527/USER1","USER1","USER1");
          PreparedStatement add=con.prepareStatement("insert into MEDICINETB values(?,?,?,?,?,?,?)");
          add.setInt(1,Integer.valueOf(MEDID.getText()));
          add.setString(2, MDNAME.getText());
          add.setInt(3,Integer.valueOf(MEDPRICE.getText()));
          add.setInt(4,Integer.valueOf(MEDQTY.getText()));
          add.setDate(5, MyfabDate);
          add.setDate(6, MyexpDate);
          add.setString(7,COMPANYCH.getSelectedItem().toString());
           int row=add.executeUpdate();
           JOptionPane.showMessageDialog(this," Medicine successfully Added");
           con.close();
           selectmed();
          
       }
       catch(SQLException e)
       {
           e.printStackTrace();
       }
    }//GEN-LAST:event_ADDBTMouseClicked

    private void DELETEBTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DELETEBTMouseClicked
        if(MEDID.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(this,"Enter The Medicine To Be Deleted");
            
        }
        else
        {
            try
            {
                 
                con= DriverManager.getConnection("jdbc:derby://localhost:1527/USER1","USER1","USER1");
                String ID = MEDID.getText();
                String Query = "Delete from USER1.MEDICINETB where MEDID="+ID;
                Statement Add=con.createStatement();
                Add.executeUpdate(Query);
                selectmed();
                JOptionPane.showMessageDialog(this,"Medicine Deleted Sucessfully");
                
            }catch(SQLException e)
            {
                e.printStackTrace();
            }
            
        }
        
    }//GEN-LAST:event_DELETEBTMouseClicked

    private void MedicineTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MedicineTableMouseClicked
        DefaultTableModel model=(DefaultTableModel)MedicineTable.getModel();
        int Myindex = MedicineTable.getSelectedRow();
        MEDID.setText(model.getValueAt(Myindex,0).toString());
        MDNAME.setText(model.getValueAt(Myindex,1).toString());
        MEDPRICE.setText(model.getValueAt(Myindex,2).toString());
        MEDQTY.setText(model.getValueAt(Myindex,3).toString()); 
         
        
    }//GEN-LAST:event_MedicineTableMouseClicked

    private void UPDATEBTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UPDATEBTMouseClicked
       if(MEDID.getText().isEmpty()||MDNAME.getText().isEmpty()||MEDPRICE.getText().isEmpty()||MEDQTY.getText().isEmpty())
       {
           JOptionPane.showMessageDialog(this,"Missing Information");
       }
       else
       {
           try{
                 FDate = MEDMAF.getDate();
                 MyfabDate = new java.sql.Date(FDate.getTime());
                 EDate = MEDEXP.getDate();
                 MyexpDate =new java.sql.Date(EDate.getTime());
               con = DriverManager.getConnection("jdbc:derby://localhost:1527/USER1","USER1","USER1");
               String UpdateQuery = "Update USER1.MEDICINETB set MEDNAME='"+MDNAME.getText()+"'"+",MEDPRICE="+MEDPRICE.getText()+""+",MEDQTY="+MEDQTY.getText()+""+",MEDFAB='"+MyfabDate+"'"+",MEDEXP='"+MyexpDate+"'"+",MEDCOMP='"+COMPANYCH.getSelectedItem().toString()+"'"+"where MEDID ="+MEDID.getText();
               Statement Add = con.createStatement();
               Add.executeUpdate(UpdateQuery);
               JOptionPane.showMessageDialog(this,"Medicine Updated Sucessfully");
           }catch(SQLException e)
           {
               e.printStackTrace();
           }
           selectmed();
       }
    }//GEN-LAST:event_UPDATEBTMouseClicked

    private void UPDATEBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UPDATEBTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UPDATEBTActionPerformed

    private void CLEARBTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CLEARBTMouseClicked
        // TODO add your handling code here:

        MEDID.setText("");
        MDNAME.setText("");
        MEDPRICE.setText("");
        MEDQTY.setText("");
       
    }//GEN-LAST:event_CLEARBTMouseClicked

    private void CLEARBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CLEARBTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CLEARBTActionPerformed

    private void COMPANYLABLEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_COMPANYLABLEMouseClicked
        new company().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_COMPANYLABLEMouseClicked

    private void CUSTOMERLABLEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CUSTOMERLABLEMouseClicked
        // TODO add your handling code here:
         new customer().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_CUSTOMERLABLEMouseClicked

    private void XMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_XMouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_XMouseClicked

    private void shalakaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shalakaMouseClicked
        // TODO add your handling code here:
        new billing().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_shalakaMouseClicked

    private void shalaka1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shalaka1MouseClicked
        // TODO add your handling code here:
        new agents().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_shalaka1MouseClicked

    private void shalaka2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shalaka2MouseClicked
        // TODO add your handling code here:
        new welcome().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_shalaka2MouseClicked

    private void shalaka3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shalaka3MouseClicked
        // TODO add your handling code here:
        new contactus().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_shalaka3MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(medicine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(medicine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(medicine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(medicine.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new medicine().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ADDBT;
    private javax.swing.JButton CLEARBT;
    private javax.swing.JLabel COMPANY;
    private javax.swing.JComboBox<String> COMPANYCH;
    private javax.swing.JLabel COMPANYLABLE;
    private javax.swing.JLabel CUSTOMERLABLE;
    private javax.swing.JButton DELETEBT;
    private javax.swing.JLabel EXPDATE;
    private javax.swing.JLabel MAFDATE;
    private javax.swing.JLabel MANAGEMEDICINE;
    private javax.swing.JTextField MDNAME;
    private com.toedter.calendar.JDateChooser MEDEXP;
    private javax.swing.JLabel MEDICINEID;
    private javax.swing.JLabel MEDICINELIST;
    private javax.swing.JTextField MEDID;
    private com.toedter.calendar.JDateChooser MEDMAF;
    private javax.swing.JLabel MEDNAME;
    private javax.swing.JTextField MEDPRICE;
    private javax.swing.JTextField MEDQTY;
    private javax.swing.JTable MedicineTable;
    private javax.swing.JLabel PRICE;
    private javax.swing.JLabel QUANTITY;
    private javax.swing.JButton UPDATEBT;
    private javax.swing.JLabel X;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel shalaka;
    private javax.swing.JLabel shalaka1;
    private javax.swing.JLabel shalaka2;
    private javax.swing.JLabel shalaka3;
    // End of variables declaration//GEN-END:variables
}
