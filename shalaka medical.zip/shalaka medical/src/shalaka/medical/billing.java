/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shalaka.medical;

import java.sql.Connection;
//import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author HP
 */
public class billing extends javax.swing.JFrame {

    /**
     * Creates new form billing
     */
    public billing() {
        initComponents();
        selectmed();
    }
    
    public void Showdate()
    {
        Date d = new Date();
        SimpleDateFormat s = new SimpleDateFormat("dd-MM-yyyy");
        DATELBL.setText(s.format(d));
    }
    
     Connection con =null;
 Statement St =null;
 ResultSet Rs =null;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        CUSTOMERID = new javax.swing.JLabel();
        QTY = new javax.swing.JLabel();
        BILLIDTXT = new javax.swing.JTextField();
        MEDTXT = new javax.swing.JTextField();
        ADDBT = new javax.swing.JButton();
        PRINTBT = new javax.swing.JButton();
        CLEARBT = new javax.swing.JButton();
        sellerlabel = new javax.swing.JLabel();
        DATELBL = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        MedicineTable = new javax.swing.JTable();
        MEDICINELIST = new javax.swing.JLabel();
        MEDICINE = new javax.swing.JLabel();
        QTYTXT = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        BILLTXT = new javax.swing.JTextArea();
        shalaka = new javax.swing.JLabel();
        CUSTOMERLABLE = new javax.swing.JLabel();
        MEDICINELABLE = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        shalaka1 = new javax.swing.JLabel();
        shalaka2 = new javax.swing.JLabel();
        shalaka3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(153, 0, 153));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel2MouseClicked(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 0, 153));
        jLabel1.setText("BILLING");

        CUSTOMERID.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        CUSTOMERID.setForeground(new java.awt.Color(153, 0, 153));
        CUSTOMERID.setText("BILL ID");

        QTY.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        QTY.setForeground(new java.awt.Color(153, 0, 153));
        QTY.setText("QTY");

        BILLIDTXT.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N

        MEDTXT.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        MEDTXT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MEDTXTActionPerformed(evt);
            }
        });

        ADDBT.setBackground(new java.awt.Color(153, 0, 153));
        ADDBT.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        ADDBT.setForeground(new java.awt.Color(255, 255, 255));
        ADDBT.setText("ADD TO BILL");
        ADDBT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ADDBTMouseClicked(evt);
            }
        });
        ADDBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ADDBTActionPerformed(evt);
            }
        });

        PRINTBT.setBackground(new java.awt.Color(153, 0, 153));
        PRINTBT.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        PRINTBT.setForeground(new java.awt.Color(255, 255, 255));
        PRINTBT.setText("PRINT");
        PRINTBT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                PRINTBTMouseClicked(evt);
            }
        });
        PRINTBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PRINTBTActionPerformed(evt);
            }
        });

        CLEARBT.setBackground(new java.awt.Color(153, 0, 153));
        CLEARBT.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        CLEARBT.setForeground(new java.awt.Color(255, 255, 255));
        CLEARBT.setText("CLEAR");
        CLEARBT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CLEARBTMouseClicked(evt);
            }
        });
        CLEARBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CLEARBTActionPerformed(evt);
            }
        });

        sellerlabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        sellerlabel.setForeground(new java.awt.Color(255, 0, 51));
        sellerlabel.setText("Seller");

        DATELBL.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        DATELBL.setForeground(new java.awt.Color(255, 0, 51));
        DATELBL.setText("Date");

        MedicineTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "MEDNAME", "PRICE", "QUANTITY", "MAFDATE", "EXPDATE", "COMPANY"
            }
        ));
        MedicineTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MedicineTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(MedicineTable);

        MEDICINELIST.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        MEDICINELIST.setForeground(new java.awt.Color(153, 0, 153));
        MEDICINELIST.setText("MEDICINES LIST");

        MEDICINE.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MEDICINE.setForeground(new java.awt.Color(153, 0, 153));
        MEDICINE.setText("MEDICINE");

        QTYTXT.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        QTYTXT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                QTYTXTActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 0, 153));
        jLabel2.setText("BILL");

        BILLTXT.setColumns(20);
        BILLTXT.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        BILLTXT.setRows(5);
        BILLTXT.setText("       ************************  MEDICINE BILL ************************\n\n\n                 ID        MEDICINE          QTY           PRICE            TOTAL\n");
        jScrollPane2.setViewportView(BILLTXT);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(sellerlabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(280, 280, 280)
                .addComponent(DATELBL)
                .addGap(76, 76, 76))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(CUSTOMERID)
                        .addGap(55, 55, 55)
                        .addComponent(BILLIDTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(MEDICINE)
                            .addComponent(QTY))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(QTYTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(MEDTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(MEDICINELIST)
                        .addGap(204, 204, 204))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 487, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(225, 225, 225))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(180, 180, 180)
                        .addComponent(ADDBT)
                        .addGap(263, 263, 263)
                        .addComponent(CLEARBT, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(388, 388, 388)
                        .addComponent(PRINTBT, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(426, 426, 426)
                        .addComponent(jLabel2)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(DATELBL)
                    .addComponent(sellerlabel))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CUSTOMERID)
                            .addComponent(BILLIDTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(MEDTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(MEDICINE))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(QTY)
                            .addComponent(QTYTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(72, 72, 72)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ADDBT)
                            .addComponent(CLEARBT)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(MEDICINELIST)
                        .addGap(12, 12, 12)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(31, 31, 31)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 254, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(PRINTBT)
                .addGap(22, 22, 22))
        );

        shalaka.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        shalaka.setForeground(new java.awt.Color(255, 255, 255));
        shalaka.setText("COMPANY");
        shalaka.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shalakaMouseClicked(evt);
            }
        });

        CUSTOMERLABLE.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        CUSTOMERLABLE.setForeground(new java.awt.Color(255, 255, 255));
        CUSTOMERLABLE.setText("CUSTOMER");
        CUSTOMERLABLE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CUSTOMERLABLEMouseClicked(evt);
            }
        });

        MEDICINELABLE.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MEDICINELABLE.setForeground(new java.awt.Color(255, 255, 255));
        MEDICINELABLE.setText("MEDICINES");
        MEDICINELABLE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MEDICINELABLEMouseClicked(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("X");
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        shalaka1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        shalaka1.setForeground(new java.awt.Color(255, 255, 255));
        shalaka1.setText("AGENTS");
        shalaka1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shalaka1MouseClicked(evt);
            }
        });

        shalaka2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        shalaka2.setForeground(new java.awt.Color(255, 255, 255));
        shalaka2.setText("HOME");
        shalaka2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shalaka2MouseClicked(evt);
            }
        });

        shalaka3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        shalaka3.setForeground(new java.awt.Color(255, 255, 255));
        shalaka3.setText("CONTACT US");
        shalaka3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shalaka3MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(MEDICINELABLE)
                    .addComponent(CUSTOMERLABLE)
                    .addComponent(shalaka)
                    .addComponent(shalaka1)
                    .addComponent(shalaka2)
                    .addComponent(shalaka3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel10)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(71, 71, 71)
                        .addComponent(shalaka2)
                        .addGap(18, 18, 18)
                        .addComponent(MEDICINELABLE)
                        .addGap(27, 27, 27)
                        .addComponent(CUSTOMERLABLE)
                        .addGap(27, 27, 27)
                        .addComponent(shalaka)
                        .addGap(27, 27, 27)
                        .addComponent(shalaka1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel10)))
                .addGap(18, 18, 18)
                .addComponent(shalaka3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 41, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public void selectmed()
  {
      try
      {
      con= DriverManager.getConnection("jdbc:derby://localhost:1527/USER1","USER1","USER1");
      St= con.createStatement();
      Rs = St.executeQuery("select * from USER1.MEDICINETB");
      MedicineTable.setModel(DbUtils.resultSetToTableModel(Rs));
      }
      catch(SQLException e)
      {
          e.printStackTrace();
      }
  }
    
    private void MEDTXTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MEDTXTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MEDTXTActionPerformed

    public void update()
    {
        int newQTY;
        newQTY = OldQty -Integer.valueOf(QTYTXT.getText());
       try{
                 
               con = DriverManager.getConnection("jdbc:derby://localhost:1527/USER1","USER1","USER1");
               String UpdateQuery = "Update USER1.MEDICINETB set MEDQTY= "+newQTY+""+"where MEDID ="+Medid;
               Statement Add = con.createStatement();
               Add.executeUpdate(UpdateQuery);
              // JOptionPane.showMessageDialog(this,"Medicine Updated Sucessfully");
           }catch(SQLException e)
           {
               e.printStackTrace();
           }
           selectmed();
       }  
    
    
    int i = 0,price,Medid,OldQty;
    private void ADDBTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ADDBTMouseClicked
           
        if(MEDTXT.getText().isEmpty() || QTYTXT.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(this," Missing Information");
        }
        
        else
        {
            i++;
            update();
           if(i == 1)
           {
        System.out.println("\n");
        BILLTXT.setText(BILLTXT.getText()+"       ************************ MEDICINE BILL ************************  \n"       
                         +"         ID        MEDICINE        QTY        PRICE         TOTAL \n"
                         +"\n"
                         +"         "+i+"        "+MEDTXT.getText()+"        "+QTYTXT.getText()+"         "+price+"        "+Integer.valueOf(QTYTXT.getText())*price);
                         System.out.println("\n");
                        
        
           }
           else
           {
            BILLTXT.setText(BILLTXT.getText()+i+"        "+MEDTXT.getText()+"        "+QTYTXT.getText()+"        "+price+"        "+Integer.valueOf(QTYTXT.getText())*price);
           System.out.println("\n");
           }
           
        }
           
   
       
        
    }//GEN-LAST:event_ADDBTMouseClicked

    private void ADDBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ADDBTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ADDBTActionPerformed

    private void PRINTBTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_PRINTBTMouseClicked
    
         try{
            BILLTXT.print();
        }catch(Exception e)
        {
            e.printStackTrace();
        }
    }//GEN-LAST:event_PRINTBTMouseClicked

    private void PRINTBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PRINTBTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PRINTBTActionPerformed

    private void CLEARBTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CLEARBTMouseClicked
        // TODO add your handling code here:

        BILLIDTXT.setText("");
        MEDTXT.setText("");
        BILLTXT.setText("");
       // CMEXPTXT.setText("");
        //CMADTXT.setText("");
       // CMPHTXT.setText("");

    }//GEN-LAST:event_CLEARBTMouseClicked

    private void CLEARBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CLEARBTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CLEARBTActionPerformed

    private void CUSTOMERLABLEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CUSTOMERLABLEMouseClicked
        // TODO add your handling code here:
        new customer().setVisible(true); 
        this.dispose();
    }//GEN-LAST:event_CUSTOMERLABLEMouseClicked

    private void MEDICINELABLEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MEDICINELABLEMouseClicked
        // TODO add your handling code here:
        new medicine().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_MEDICINELABLEMouseClicked

    private void MedicineTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MedicineTableMouseClicked
        DefaultTableModel model=(DefaultTableModel)MedicineTable.getModel();
        int Myindex = MedicineTable.getSelectedRow();
        MEDTXT.setText(model.getValueAt(Myindex,1).toString());
         Medid = Integer.valueOf(model.getValueAt(Myindex,0).toString());
        //MDNAME.setText(model.getValueAt(Myindex,1).toString());
         price= Integer.valueOf( model.getValueAt(Myindex,2).toString());
         OldQty=Integer.valueOf( model.getValueAt(Myindex,3).toString());
        //MEDQTY.setText(model.getValueAt(Myindex,3).toString());

    }//GEN-LAST:event_MedicineTableMouseClicked

    private void QTYTXTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_QTYTXTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_QTYTXTActionPerformed

    private void jPanel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel2MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel2MouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jLabel10MouseClicked

    private void shalakaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shalakaMouseClicked
        // TODO add your handling code here:
        new company().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_shalakaMouseClicked

    private void shalaka1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shalaka1MouseClicked
        // TODO add your handling code here:
        new agents().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_shalaka1MouseClicked

    private void shalaka2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shalaka2MouseClicked
        // TODO add your handling code here:
         new welcome().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_shalaka2MouseClicked

    private void shalaka3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shalaka3MouseClicked
        // TODO add your handling code here:
         new contactus().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_shalaka3MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) { 
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(billing.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(billing.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(billing.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(billing.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new billing().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ADDBT;
    private javax.swing.JTextField BILLIDTXT;
    private javax.swing.JTextArea BILLTXT;
    private javax.swing.JButton CLEARBT;
    private javax.swing.JLabel CUSTOMERID;
    private javax.swing.JLabel CUSTOMERLABLE;
    private javax.swing.JLabel DATELBL;
    private javax.swing.JLabel MEDICINE;
    private javax.swing.JLabel MEDICINELABLE;
    private javax.swing.JLabel MEDICINELIST;
    private javax.swing.JTextField MEDTXT;
    private javax.swing.JTable MedicineTable;
    private javax.swing.JButton PRINTBT;
    private javax.swing.JLabel QTY;
    private javax.swing.JTextField QTYTXT;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel sellerlabel;
    private javax.swing.JLabel shalaka;
    private javax.swing.JLabel shalaka1;
    private javax.swing.JLabel shalaka2;
    private javax.swing.JLabel shalaka3;
    // End of variables declaration//GEN-END:variables
}
