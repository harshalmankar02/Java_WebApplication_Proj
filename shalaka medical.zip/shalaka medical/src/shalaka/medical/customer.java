/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shalaka.medical;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author HP
 */
public class customer extends javax.swing.JFrame {

    /**
     * Creates new form customer
     */
    public customer() {
        initComponents();
        selectmed();
    }

   Connection con =null;
 Statement St =null;
 ResultSet Rs =null;
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        ID = new javax.swing.JLabel();
        NAME = new javax.swing.JLabel();
        GENDER = new javax.swing.JLabel();
        PHONENO = new javax.swing.JLabel();
        CSIDTXT = new javax.swing.JTextField();
        CSPHTXT = new javax.swing.JTextField();
        CSNAMETXT = new javax.swing.JTextField();
        CSAGETXT = new javax.swing.JTextField();
        ADDBT = new javax.swing.JButton();
        UPDATEBT = new javax.swing.JButton();
        DELETEBT = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        CSLISTTB = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        CLEARBT = new javax.swing.JButton();
        AGE = new javax.swing.JLabel();
        GENDERCH = new javax.swing.JComboBox();
        ADDRESS = new javax.swing.JLabel();
        CSADTXT = new javax.swing.JTextField();
        shalaka = new javax.swing.JLabel();
        COMPANYLABLE = new javax.swing.JLabel();
        MEDICINELABLE = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        shalaka1 = new javax.swing.JLabel();
        shalaka2 = new javax.swing.JLabel();
        shalaka3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(153, 0, 153));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 0, 153));
        jLabel1.setText("MANAGE CUSTOMER");

        ID.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        ID.setForeground(new java.awt.Color(153, 0, 153));
        ID.setText("ID");

        NAME.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        NAME.setForeground(new java.awt.Color(153, 0, 153));
        NAME.setText("NAME");

        GENDER.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        GENDER.setForeground(new java.awt.Color(153, 0, 153));
        GENDER.setText("GENDER");

        PHONENO.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        PHONENO.setForeground(new java.awt.Color(153, 0, 153));
        PHONENO.setText("PHONE NO");

        CSIDTXT.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N

        CSPHTXT.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        CSPHTXT.setForeground(new java.awt.Color(102, 0, 153));
        CSPHTXT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CSPHTXTActionPerformed(evt);
            }
        });

        CSNAMETXT.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        CSNAMETXT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CSNAMETXTActionPerformed(evt);
            }
        });

        CSAGETXT.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        CSAGETXT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CSAGETXTActionPerformed(evt);
            }
        });

        ADDBT.setBackground(new java.awt.Color(153, 0, 153));
        ADDBT.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        ADDBT.setForeground(new java.awt.Color(255, 255, 255));
        ADDBT.setText("ADD");
        ADDBT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ADDBTMouseClicked(evt);
            }
        });
        ADDBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ADDBTActionPerformed(evt);
            }
        });

        UPDATEBT.setBackground(new java.awt.Color(153, 0, 153));
        UPDATEBT.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        UPDATEBT.setForeground(new java.awt.Color(255, 255, 255));
        UPDATEBT.setText("UPDATE");
        UPDATEBT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                UPDATEBTMouseClicked(evt);
            }
        });
        UPDATEBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UPDATEBTActionPerformed(evt);
            }
        });

        DELETEBT.setBackground(new java.awt.Color(153, 0, 153));
        DELETEBT.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        DELETEBT.setForeground(new java.awt.Color(255, 255, 255));
        DELETEBT.setText("DELETE");
        DELETEBT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DELETEBTMouseClicked(evt);
            }
        });
        DELETEBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DELETEBTActionPerformed(evt);
            }
        });

        CSLISTTB.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "NAME", "AGE", "GENDER", "ADDRESS", "PHONE"
            }
        ));
        CSLISTTB.setRowHeight(25);
        CSLISTTB.setSelectionBackground(new java.awt.Color(153, 0, 153));
        CSLISTTB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CSLISTTBMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(CSLISTTB);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(153, 0, 153));
        jLabel9.setText("CUSTOMERS LIST");

        CLEARBT.setBackground(new java.awt.Color(153, 0, 153));
        CLEARBT.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        CLEARBT.setForeground(new java.awt.Color(255, 255, 255));
        CLEARBT.setText("CLEAR");
        CLEARBT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CLEARBTMouseClicked(evt);
            }
        });
        CLEARBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CLEARBTActionPerformed(evt);
            }
        });

        AGE.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        AGE.setForeground(new java.awt.Color(153, 0, 153));
        AGE.setText("AGE");

        GENDERCH.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MALE", "FEMALE", "OTHER" }));

        ADDRESS.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        ADDRESS.setForeground(new java.awt.Color(153, 0, 153));
        ADDRESS.setText("ADDRESS");

        CSADTXT.setFont(new java.awt.Font("Segoe UI", 1, 11)); // NOI18N
        CSADTXT.setForeground(new java.awt.Color(102, 0, 153));
        CSADTXT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CSADTXTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(NAME)
                    .addComponent(ID)
                    .addComponent(AGE))
                .addGap(111, 111, 111)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(CSNAMETXT, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CSIDTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CSAGETXT, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(PHONENO)
                        .addGap(49, 49, 49)
                        .addComponent(CSPHTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(GENDER)
                            .addComponent(ADDRESS))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(CSADTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(GENDERCH, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(357, 357, 357)
                        .addComponent(jLabel1))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(237, 237, 237)
                        .addComponent(ADDBT, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(54, 54, 54)
                        .addComponent(UPDATEBT, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46)
                        .addComponent(DELETEBT, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)
                        .addComponent(CLEARBT, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 132, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 797, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(59, 59, 59))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(366, 366, 366))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel1)
                .addGap(40, 40, 40)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(ID)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(CSIDTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(CSPHTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(PHONENO)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(UPDATEBT)
                            .addComponent(DELETEBT)
                            .addComponent(CLEARBT))
                        .addGap(35, 35, 35))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(NAME)
                            .addComponent(CSNAMETXT, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(GENDER)
                            .addComponent(GENDERCH, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(CSAGETXT, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ADDRESS)
                                    .addComponent(CSADTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addComponent(AGE)))
                        .addGap(31, 31, 31)
                        .addComponent(ADDBT)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)))
                .addComponent(jLabel9)
                .addGap(27, 27, 27)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 302, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );

        shalaka.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        shalaka.setForeground(new java.awt.Color(255, 255, 255));
        shalaka.setText("BILLING");
        shalaka.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shalakaMouseClicked(evt);
            }
        });

        COMPANYLABLE.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        COMPANYLABLE.setForeground(new java.awt.Color(255, 255, 255));
        COMPANYLABLE.setText("COMPANY");
        COMPANYLABLE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                COMPANYLABLEMouseClicked(evt);
            }
        });

        MEDICINELABLE.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        MEDICINELABLE.setForeground(new java.awt.Color(255, 255, 255));
        MEDICINELABLE.setText("MEDICINES");
        MEDICINELABLE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MEDICINELABLEMouseClicked(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("X");
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        shalaka1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        shalaka1.setForeground(new java.awt.Color(255, 255, 255));
        shalaka1.setText("AGENT");
        shalaka1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shalaka1MouseClicked(evt);
            }
        });

        shalaka2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        shalaka2.setForeground(new java.awt.Color(255, 255, 255));
        shalaka2.setText("CONTACT US");
        shalaka2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shalaka2MouseClicked(evt);
            }
        });

        shalaka3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        shalaka3.setForeground(new java.awt.Color(255, 255, 255));
        shalaka3.setText("HOME");
        shalaka3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shalaka3MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(MEDICINELABLE)
                    .addComponent(COMPANYLABLE)
                    .addComponent(shalaka2)
                    .addComponent(shalaka3)
                    .addComponent(shalaka)
                    .addComponent(shalaka1))
                .addGap(33, 33, 33)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(48, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel10)
                .addGap(18, 18, 18))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addComponent(shalaka3)
                        .addGap(18, 18, 18)
                        .addComponent(MEDICINELABLE)
                        .addGap(18, 18, 18)
                        .addComponent(COMPANYLABLE)
                        .addGap(18, 18, 18)
                        .addComponent(shalaka)
                        .addGap(18, 18, 18)
                        .addComponent(shalaka1)
                        .addGap(18, 18, 18)
                        .addComponent(shalaka2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public void selectmed()
  {
      try
      {
      con= DriverManager.getConnection("jdbc:derby://localhost:1527/USER1","USER1","USER1");
      St= con.createStatement();
      Rs = St.executeQuery("select * from USER1.CUSTOMERTB");
      CSLISTTB.setModel(DbUtils.resultSetToTableModel(Rs));
      }
      catch(SQLException e)
      {
          e.printStackTrace();
      }
      
  }
    
    private void CSPHTXTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CSPHTXTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CSPHTXTActionPerformed

    private void CSNAMETXTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CSNAMETXTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CSNAMETXTActionPerformed

    private void CSAGETXTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CSAGETXTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CSAGETXTActionPerformed

    private void ADDBTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ADDBTMouseClicked
        try
        {
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/USER1","USER1","USER1");
            PreparedStatement add=con.prepareStatement("insert into CUSTOMERTB values(?,?,?,?,?,?)");
            add.setInt(1,Integer.valueOf(CSIDTXT.getText()));
            add.setString(2, CSNAMETXT.getText());
            add.setInt(3,Integer.valueOf(CSAGETXT.getText()));
            
            add.setString(4,GENDERCH.getSelectedItem().toString());
            add.setString(5, CSADTXT.getText());
            add.setString(6, CSPHTXT.getText());

            int row=add.executeUpdate();
            JOptionPane.showMessageDialog(this," Customer successfully Added");
            con.close();

           selectmed();

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }//GEN-LAST:event_ADDBTMouseClicked

    private void ADDBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ADDBTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ADDBTActionPerformed

    private void UPDATEBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UPDATEBTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UPDATEBTActionPerformed

    private void DELETEBTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DELETEBTMouseClicked
        if(CSIDTXT.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(this,"Enter The Customber To Be Deleted");

        }
        else
        {
            try
            {

                con= DriverManager.getConnection("jdbc:derby://localhost:1527/USER1","USER1","USER1");
                String ID = CSIDTXT.getText();
                String Query = "Delete from USER1.CUSTOMERTB where CSID="+ID;
                Statement Add=con.createStatement();
                Add.executeUpdate(Query);
                selectmed();
                JOptionPane.showMessageDialog(this,"Customer Deleted Sucessfully");

            }catch(SQLException e)
            {
                e.printStackTrace();
            }

        }

    }//GEN-LAST:event_DELETEBTMouseClicked

    private void DELETEBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DELETEBTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DELETEBTActionPerformed

    private void CSLISTTBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CSLISTTBMouseClicked
        DefaultTableModel model=(DefaultTableModel)CSLISTTB.getModel();
        int Myindex = CSLISTTB.getSelectedRow();
        CSIDTXT.setText(model.getValueAt(Myindex,0).toString());
        CSNAMETXT.setText(model.getValueAt(Myindex,1).toString());
        CSAGETXT.setText(model.getValueAt(Myindex,2).toString());
        
        CSADTXT.setText(model.getValueAt(Myindex,4).toString());
        CSPHTXT.setText(model.getValueAt(Myindex,5).toString());
    }//GEN-LAST:event_CSLISTTBMouseClicked

    private void CLEARBTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CLEARBTMouseClicked
        // TODO add your handling code here:

        CSIDTXT.setText("");
        CSNAMETXT.setText("");
        CSAGETXT.setText("");
        CSPHTXT.setText("");
        CSADTXT.setText("");

    }//GEN-LAST:event_CLEARBTMouseClicked

    private void CLEARBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CLEARBTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CLEARBTActionPerformed

    private void CSADTXTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CSADTXTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CSADTXTActionPerformed

    private void UPDATEBTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_UPDATEBTMouseClicked
         if(CSIDTXT.getText().isEmpty()||CSNAMETXT.getText().isEmpty()||CSAGETXT.getText().isEmpty()||CSADTXT.getText().isEmpty()||CSPHTXT.getText().isEmpty())
       {
           JOptionPane.showMessageDialog(this,"Missing Information");
       }
       else
       {
           try{
                
               con = DriverManager.getConnection("jdbc:derby://localhost:1527/USER1","USER1","USER1");
               String UpdateQuery = "Update USER1.CUSTOMERTB set CSNAME='"+CSNAMETXT.getText()+"'"+",CSAGE="+CSAGETXT.getText()+""+",CSGENDER='"+GENDERCH.getSelectedItem().toString()+"'"+",CSAD='"+CSADTXT.getText()+"'"+",CSPHONE='"+CSPHTXT.getText()+"'"+"where CSID ="+CSIDTXT.getText();
               Statement Add = con.createStatement();
               Add.executeUpdate(UpdateQuery);
               JOptionPane.showMessageDialog(this,"Customer Updated Sucessfully");
           }catch(SQLException e)
           {
               e.printStackTrace();
           }
           selectmed();
       }
    }//GEN-LAST:event_UPDATEBTMouseClicked

    private void MEDICINELABLEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MEDICINELABLEMouseClicked
        // TODO add your handling code here:
        new medicine().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_MEDICINELABLEMouseClicked

    private void COMPANYLABLEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_COMPANYLABLEMouseClicked
        // TODO add your handling code here:
        new company().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_COMPANYLABLEMouseClicked

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jLabel10MouseClicked

    private void shalakaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shalakaMouseClicked
        // TODO add your handling code here:
        new billing().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_shalakaMouseClicked

    private void shalaka1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shalaka1MouseClicked
        // TODO add your handling code here:
        new agents().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_shalaka1MouseClicked

    private void shalaka2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shalaka2MouseClicked
        // TODO add your handling code here:
        new contactus().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_shalaka2MouseClicked

    private void shalaka3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shalaka3MouseClicked
        // TODO add your handling code here:
         new welcome().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_shalaka3MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(customer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new customer().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ADDBT;
    private javax.swing.JLabel ADDRESS;
    private javax.swing.JLabel AGE;
    private javax.swing.JButton CLEARBT;
    private javax.swing.JLabel COMPANYLABLE;
    private javax.swing.JTextField CSADTXT;
    private javax.swing.JTextField CSAGETXT;
    private javax.swing.JTextField CSIDTXT;
    private javax.swing.JTable CSLISTTB;
    private javax.swing.JTextField CSNAMETXT;
    private javax.swing.JTextField CSPHTXT;
    private javax.swing.JButton DELETEBT;
    private javax.swing.JLabel GENDER;
    private javax.swing.JComboBox GENDERCH;
    private javax.swing.JLabel ID;
    private javax.swing.JLabel MEDICINELABLE;
    private javax.swing.JLabel NAME;
    private javax.swing.JLabel PHONENO;
    private javax.swing.JButton UPDATEBT;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel shalaka;
    private javax.swing.JLabel shalaka1;
    private javax.swing.JLabel shalaka2;
    private javax.swing.JLabel shalaka3;
    // End of variables declaration//GEN-END:variables
}
